﻿/*
 * Created by SharpDevelop.
 * User: Lmx2315
 * Date: 09/10/2018
 * Time: 16:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace fft_writer
{
	/// <summary>
	/// Description of LogWriter.
	/// </summary>
	public class LogWriter
	{

	}
}
