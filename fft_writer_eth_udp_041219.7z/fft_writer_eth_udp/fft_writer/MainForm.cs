﻿/*
 * Created by SharpDevelop.
 * User: Lmx2315
 * Date: 08/08/2018
 * Time: 13:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using PlotWrapper;
using DSPLib;
using System.Numerics;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.Text;
using MinimalisticTelnet;
//using FFTLibrary;


namespace fft_writer
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
        delegate void ShowMessageMethod(string msg);

        public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			Debug.WriteLine("Debug Information-Product Starting ");
			Debug.WriteLine("------------------------ ");

		}
        //----------ETH------------
        UdpClient _server = null;
        IPEndPoint _client = null;
        Thread _listenThread = null;
        private bool _isServerStarted = false;

        Class1 rcv_func=new Class1();
		Form1 fft_form     = new Form1();
		
		static int  BUF_N= 64000;
		static int Fsample=12;

		Byte  [] RCV         =new byte[64000];
		int   [] FFT_array   =new int [64000];
	    int   [] packet_data =new int [64000];
        int   [] packet_data_i = new int [64000];
        int   [] packet_data_q = new int [64000];
        Byte  [] rcv_BUF     =new byte[64000];
        double B_win = 1;
  
		int flag_NEW_FFT;
        byte[] buf = new byte[64];

        double filtr = 0;
        int sch_packet = 0;
        int FLAG_filtr = 0;

        string fileName;
        string text_from_file;
        int Flag_comport_rcv = 0;

         Plot fig1 = new Plot(100,"I Input", "Sample", "Вольт","","","","","");
	     Plot fig2 = new Plot(100,"Q Input", "Sample", "Вольт","","","","","");
		 Plot fig3 = new Plot(85,"FFT (dBV)", "кГц", "Mag (dBV)","","","","","");
         Plot fig4 = new Plot(85,"FFT (dBV)", "кГц", "Mag (dBV)", "", "", "", "", "");

        private void MainForm_FormClosing(Object sender, FormClosingEventArgs e)
        {
            DialogResult dialog = MessageBox.Show(
               "Вы действительно хотите выйти из программы?",
               "Завершение программы",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Warning
              );
            if (dialog == DialogResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }

          if (_isServerStarted)   _server.Close();
            //Changet state to indicate the server stops.
            _isServerStarted = false;
        }
        //-------------------eth-------------------------
        private void Start()
        {
            IPAddress my_ip;
            UInt16 my_port;

            my_ip = IPAddress.Parse(my_ip_box.Text);
            my_port = UInt16.Parse(my_port_box.Text);

            //Create the server.
               IPEndPoint serverEnd = new IPEndPoint(my_ip, my_port);           
            // IPEndPoint serverEnd = new IPEndPoint(IPAddress.Any, 1234);

            _server = new UdpClient(serverEnd);
            _server.Client.ReceiveBufferSize = 8192 * 200;//увеличиваем размер приёмного буфера!!!
            Debug.WriteLine("Waiting for a client...");
            //Create the client end.
            //_client = new IPEndPoint(IPAddress.Any, 0);
           
            //Start listening.
            Thread listenThread = new Thread(new ThreadStart(Listening));
            listenThread.Start();
            //Change state to indicate the server starts.
            _isServerStarted = true;

            //-----шлём приветствие программсе на си--------------
            UdpClient client = new UdpClient();
            client.Connect("127.0.0.1", 666);

            string msg = "Hello bro!!!\n";
            byte[] data = Encoding.UTF8.GetBytes(msg);
            int number_bytes = client.Send(data, data.Length);
            client.Close();
        }

        private void Stop()
        {
            try
            {
                //Stop listening.
                _listenThread.Join();
                Debug.WriteLine("Server stops.");
                _server.Close();
                //Changet state to indicate the server stops.
                _isServerStarted = false;
            }
            catch (Exception excp)
            { }
        }

        int FLAG_UDP_RCV = 0;

        private void Listening()
        {
            byte[] data;
            //Listening loop.
            while (true)
            {
                //receieve a message form a client.
                data = _server.Receive(ref _client);
                if(FLAG_UDP_RCV==0)
                {
                    //  receivedMsg = Encoding.ASCII.GetString(data, 0, data.Length);
                    Array.Copy(data, RCV, data.Length);//копируем массив отсчётов в форму обработки                    
                      FLAG_UDP_RCV = 1;
                }
                sch_packet++;
            }
        }
         
        byte [] BUFFER_1 = new byte[64000];
        byte [] BUFFER_2 = new byte[64000];

        void MSG_collector()
        {

           if (RCV[3] == 1) Array.Copy(RCV, BUFFER_1, BUF_N*4);//копируем массив отсчётов в форму обработки 
           if (RCV[3] == 2) Array.Copy(RCV, BUFFER_2, BUF_N*4);//

            if (Convert.ToByte(channal_box.Text) == 1) { BUF_convert(BUFFER_1, BUF_N*4); }
            if (Convert.ToByte(channal_box.Text) == 2) { BUF_convert(BUFFER_2, BUF_N*4); }

            work1();

            if (flag_NEW_FFT == 1)
            {
                fft_out();
                flag_NEW_FFT = 0;
            }
        }

        private void ShowMsg(string msg)
        {
            this.Console1.Text += msg + "\r\n";
        }
        //-----------------------------------------------

        void Timer1Tick ()
        {

        }

        Byte sch =0;

        Byte[] cos_gen ()
        {
            Byte[] data = new byte[1446];

            int i = 0;
            int n = 0;
            double z = 0;
            int x = 0;

            if (sch < 254) sch++; else sch = 0;

            i = 6;

            data[0] = 0;
            data[1] = 1;
            data[2] = 0;
            data[3] = 0;
            data[4] = 0;
            data[5] = sch;

            for (n=0;n<360;n++)
            {
                z = 30000 * Math.Cos(2 * Math.PI * i / 20);
                x = Convert.ToInt16(z);
             //   Debug.WriteLine("x:" + x);
                data[i  ] = Convert.ToByte((x >> 8) & 0xff);
                data[i+1] = Convert.ToByte((x >> 0) & 0xff);
        
                z = 30000 * Math.Cos(2 * Math.PI * i / 20);
                x = Convert.ToInt16(z);

                data[i+2] = Convert.ToByte((x >> 8) & 0xff);
                data[i+3] = Convert.ToByte((x >> 0) & 0xff);
    
                i = i + 4;
            }

            return data;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (FLAG_UDP_RCV==1)
            {
                MSG_collector();
                FLAG_UDP_RCV = 0;
            }            

            textBox_sch.Text = Convert.ToString(sch_packet);

            sch_packet = 0;
            filtr = 12000 / BUF_N * B_win;
            label8.Text = "полоса фильтра:" + Convert.ToString(filtr) + "кГц";
        }

    
		void MainFormLoad(object sender, EventArgs e)
		{
			//fft_form.Show(this);
			BUF_N =Convert.ToInt16(text_N_fft.Text);
			// Load window combo box with the Window Names (from ENUMS)
            cmbWindow.DataSource = Enum.GetNames(typeof(DSPLib.DSP.Window.Type));            
        }

        // Calculate log(number) in the indicated log base.
        private double LogBase(double number, double log_base)
        {
            return Math.Log(number) / Math.Log(log_base);
        }

        int post_U_i=0;
        int post_U_q=0;

        double H_a = 0;//максимальный уровень сигнала в спектре
        double H_b = 0;//вторая максимальная гармоника в спектре
        double H_delta = 0;

        double[] H_q = { -1.63929, -0.509389, -1.26251, -0.930825, -1.01963, -0.378371, -3.88231, 1.13213, -1.78198, -2.28298, 2.64348, -8.54228, 9.06021, -11.3554, 6.14724, -1.27089, -9.80482, 26.264, -33.0313, 28.3865, -17.6925, -1.79624, 23.4104, -46.5853, 54.664, -52.6287, 31.9712, -6.26728, -35.5789, 58.0711, -66.3911, 49.1152, -26.9365, 2.04138, 12.7328, -13.9691, -5.19284, 24.6977, -34.8751, 5.77896, 58.9198, -154.583, 235.497, -260.575, 207.644, -41.4462, -225.661, 519.895, -727.933, 772.647, -605.157, 135.415, 569.447, -1392.94, 1526.87, -1652.87, 1254.04, -343.638, -916.289, 2715.21, -2844.23, 7579.37, -5919.88, -3108.24, 57189.5, -3090.09, -5850.81, 7446.63, -2777.74, 2635.58, -883.949, -329.431, 1194.13, -1563.35, 1433.86, -1298.52, 526.591, 124.114, -550.14, 695.34, -648.269, 457.246, -195.942, -35.5385, 173.791, -213.369, 186.652, -117.846, 41.809, 3.34895, -18.1347, 2.83758, 15.2314, -27.6292, 18.476, 2.748, -30.6111, 53.4632, -69.5996, 59.3086, -35.5331, -6.16296, 30.7938, -50.0568, 51.1771, -43.1862, 21.3146, -1.71922, -15.9003, 24.9209, -28.9129, 22.4619, -8.47742, -1.22682, 4.89226, -9.38984, 6.98833, -6.84603, 1.73952, -1.92625, -1.53218, 0.316827, -2.45997, -0.84718, -0.975004, -0.845982, -1.34692, -0.470157 };
        double[] H_i = { -1, -0.691066, -1.34306, -0.765836, -0.758238, -2.48481, -2.68952, 1.93226, -5.18299, 3.37767, -5.54536, 1.43398, 1.10731, -8.96622, 13.3589, -19.7412, 19.9276, -10.991, -5.93263, 20.958, -36.9664, 41.3697, -39.6046, 20.4839, 3.0028, -33.4357, 53.7366, -65.5334, 56.4144, -31.6381, -4.9379, 33.3707, -45.0648, 40.2995, -27.1577, 6.8383, -0.966546, 12.496, -48.2195, 91.26, -116.62, 90.7343, 13.1179, -129.001, 284.058, -419.624, 452.331, -320.217, 35.1626, 341.261, -779.551, 1122.74, -1154.21, 585.212, -110.956, -605.227, 1609.83, -2176.46, 2744.31, -1564.56, 1875.21, 657.78, -8350.18, 16130.7, -1, -16038.5, 8250.74, -648.245, -1833.34, 1516.72, -2649.31, 2084.26, -1534.93, 570.482, 102.263, -547.448, 1065.58, -1031.65, 706.653, -309.061, -33.1996, 279.824, -394.362, 356.479, -239.807, 103.723, -12.2021, -70.7914, 81.6034, -60.1881, 22.8845, -3.01543, -0.870494, -17.0942, 36.0971, -51.8947, 49.3078, -38.3527, 3.13112, 30.2799, -58.3383, 62.2553, -53.7819, 29.8199, -4.75205, -20.882, 34.2903, -39.2713, 31.1047, -20.3684, 3.29842, 7.59772, -18.7726, 14.6919, -12.8377, 5.45417, -2.67331, -2.88658, 2.41764, -4.16045, 1.84676, -2.811, -0.14421, -0.634978, -0.692191, -1.52136, -0.546623, -1.33364 };


        void fft_out ()
		{

            UInt32 zeros = Convert.ToUInt32(0);
            uint N_temp;
            int N_complex;
            int i;
            int N;
            uint z;
            int step = 0;
            int pstep = 0;

            int N_correct = 128;

            N_temp    = Convert.ToUInt32(BUF_N);
            N_complex = Convert.ToInt32 (BUF_N);

            double A_max = 0;
            double B_max = 0;
            double C_max = 0;

            double[] m_sort = new double[BUF_N];

            double[] fft_array = new double[BUF_N];
            double[] fft_array_x = new double[BUF_N];
            double[] fft_array_y = new double[BUF_N];

            double[] t = new double[BUF_N];
            double[] A = new double[BUF_N];

            string selectedWindowName = cmbWindow.SelectedValue.ToString();

            DSPLib.DSP.Window.Type windowToApply = (DSPLib.DSP.Window.Type)Enum.Parse(typeof(DSPLib.DSP.Window.Type), selectedWindowName);

            for (i = 0; i < N_temp; i++)
            {
                //fft_array_x[i] = Convert.ToDouble(packet_data_i[i]- rcv_func.mat_oj_i); //удаляем постояннуюу составляющую высчитанную ранее
                //fft_array_y[i] = Convert.ToDouble(packet_data_q[i]- rcv_func.mat_oj_q);

                if (packet_data_i[i] > 32767)
                {
                    z = (uint)(packet_data_i[i]);
                    z = (~z) & 0xffff;
                    packet_data_i[i] = -1 * Convert.ToInt32(z + 1);
                }
                else packet_data_i[i] = Convert.ToInt32(packet_data_i[i]);

                if (packet_data_q[i] > 32767)
                {
                    z = (uint)(packet_data_q[i]);
                    z = (~z) & 0xffff;
                    packet_data_q[i] = -1 * Convert.ToInt32(z + 1);
                }
                else packet_data_q[i] = Convert.ToInt32(packet_data_q[i]);

                fft_array_x[i] = Convert.ToDouble(packet_data_i[i]- post_U_i); //
                fft_array_y[i] = Convert.ToDouble(packet_data_q[i]- post_U_q);
            }

      //  Plot Time Series data
      //      fig1.PlotData(windowedTimeSeries_q);
     //       fig1.Show();

       //  Plot Time Series data
       //     fig2.PlotData(windowedTimeSeries_i);
       //     fig2.Show();

            // Instantiate & Initialize the FFT class - это вещественная FFt сейчас не используем.
//            DSPLib.FFT fft = new DSPLib.FFT();
//            fft.Initialize(2 * N_temp, zeros);
              
         // Start a Stopwatch
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            int k = Convert.ToInt16(LogBase(N_temp, 2));//порядок БПФ

            // Perform a DFT
            // System.Numerics.Complex[] cpxResult = fft.Execute(windowedTimeSeries);

            FFTLibrary.Complex fft_z = new FFTLibrary.Complex();
            FFTLibrary.Complex fft_h = new FFTLibrary.Complex();//fft для импульсной характеристики фильтра
   //       FFTLibrary.Complex fft_x = new FFTLibrary.Complex();//fft для водных данных

            double[] fh_i = new double[N_temp * 2];
            double[] fh_q = new double[N_temp * 2];

            Array.Copy(H_i, fh_i, N_correct);
            Array.Copy(H_q, fh_q, N_correct);

            double[] fx_i = new double[N_temp * 2];
            double[] fx_q = new double[N_temp * 2];

            Array.Copy(fft_array_x, fx_i, N_temp);
            Array.Copy(fft_array_y, fx_q, N_temp);

            //БПФ должно быть размером больше чем длинна ИХ фильтра + длинна вектора данных - 1 !!!
            fft_h.FFT(1, k+1, fh_i, fh_q);                  //расчитываем БПФ от импульсной характеристики фильтра
            fft_h.FFT(1, k+1, fx_i, fx_q);                  //расчитываем БПФ от входных данных

            System.Numerics.Complex[] HxResult = new System.Numerics.Complex[N_complex * 2];//комплексный массив для комплексной ИХ
            System.Numerics.Complex[] XxResult = new System.Numerics.Complex[N_complex * 2];//комплексный массив для обработанных БПФ данных
            System.Numerics.Complex[] ZxResult = new System.Numerics.Complex[N_complex * 2];//комплексный массив для обработанных БПФ данных

            for (i = 0; i < (N_complex*2); i++)
            {
                         HxResult[i] = new System.Numerics.Complex(fh_i[i], fh_q[i]);//конвертируем в комплексный вектор
                         XxResult[i] = new System.Numerics.Complex(fx_i[i], fx_q[i]);
                         ZxResult[i] = Complex.Multiply(HxResult[i], XxResult[i]);   //перемножаем комплексные числа обработанной ИХ и входных данных
                         ZxResult[i] = Complex.Divide(ZxResult[i],10);
            }

            for (i = 0; i < (N_complex * 2); i++)
            {
                fx_i[i] = ZxResult[i].Real;
                fx_q[i] = ZxResult[i].Imaginary;
            }

            fft_h.FFT(-1, k + 1, fx_i, fx_q);//высчитываем обратное  БПФ 

            if (btn_corr_spectr.Text=="ON") //включена коррекция АЧХ
            {
                Array.Copy(fx_i, fft_array_x, N_temp);
                Array.Copy(fx_q, fft_array_y, N_temp);
            }
            

            // Apply window to the time series data
            double[] wc = DSP.Window.Coefficients(windowToApply, N_temp);
            double windowScaleFactor = DSP.Window.ScaleFactor.Signal(wc);

            double[] windowedTimeSeries_i = DSP.Math.Multiply(fft_array_x, wc);
            double[] windowedTimeSeries_q = DSP.Math.Multiply(fft_array_y, wc);           

            fft_z.FFT(1, k, windowedTimeSeries_i, windowedTimeSeries_q);

            System.Numerics.Complex[] cpxResult = new System.Numerics.Complex[N_complex];

            for (i = 0; i < N_complex; i++)
            {
                cpxResult[i] = new System.Numerics.Complex(windowedTimeSeries_i[i], windowedTimeSeries_q[i]);
            }

            // Convert the complex result to a scalar magnitude 
            double[] magResult = DSP.ConvertComplex.ToMagnitude(cpxResult);
            magResult = DSP.Math.Multiply(magResult, 1);

            // Calculate the frequency span
    //        double[] fSpan = fft.FrequencySpan(2 * Fsample);

            // Convert and Plot Log Magnitude
            double[] mag = DSP.ConvertComplex.ToMagnitude(cpxResult);
            mag = DSP.Math.Multiply(mag, 1);
            double[] magLog = DSP.ConvertMagnitude.ToMagnitudeDBV(mag);
            int j;

            for (j = 0; j < N_temp; j++)
            {
			//	 A[j] = magLog[j];
                if (j < ( N_temp / 2))      A[j] = magLog[j + (N_temp / 2)];
                if (j > ((N_temp / 2) - 1)) A[j] = magLog[j - (N_temp / 2)];
                  t[j] = -3121+(6250*j/(N_temp));//важно сначала умножить а потом поделить!!!! атоноль
				// Debug.WriteLine("t[]:"+t[j]);
            }

            for (j = 0; j < N_temp; j++)
            {
                    magLog[j] = A[N_temp - 1 - j];
                if (magLog[j] < 0) magLog[j] = 0;
            }

            if (FLAG_filtr == 1) vid_filtr(magLog);
            if (FLAG_filtr == 2)
            {                 
                vid_filtr (magLog);
                vid2_filtr(magLog);
                vid3_filtr(magLog);
                vid4_filtr(magLog);
            }

            int k_max = 0;
            double m1x,m1y;
            double m2x,m2y;
            double m3x,m3y;
            
            Array.Copy(magLog, m_sort,  BUF_N);

            (k_max,A_max) = MAX_f(magLog, BUF_N);       //определяем Х координату первого максимума
            m1x = t[k_max];
            m1y = A_max;

            if (BUF_N>2048) step = (BUF_N / 80)-20; else step = (BUF_N / 80)    ;

            pstep = step / 2;

            if (k_max> pstep && k_max< (BUF_N- step))   for (i=0;i< step; i++) m_sort[k_max + i- pstep] = 0;

            (k_max,B_max) = MAX_f(m_sort, BUF_N);      //определяем Х координату второго максимума
            m2x = t[k_max];
            m2y = B_max;                                //определяем второй максимум
           
            if (k_max > pstep && k_max < (BUF_N - step)) for (i = 0; i < step; i++) m_sort[k_max + i - pstep] = 0;

            (k_max,C_max) = MAX_f(m_sort, BUF_N); 
    
            m3y =  C_max;
            m3x =  t[k_max];;

            H_a = m1y;
            H_b = m2y;
            H_delta = m1y - m2y;

          //  magLog[0] = 80;//выравниваю шкалу
            fig3.PlotData(t,magLog, A_max, B_max,C_max,m1x,m1y,m2x,m2y,m3x,m3y);
            fig3.Show();
        }

        double[] Z0 = new double[BUF_N];
        double[] Z1 = new double[BUF_N];
        double[] Z2 = new double[BUF_N];
        double[] Z3 = new double[BUF_N];
        double[] Z4 = new double[BUF_N];
        double[] Z5 = new double[BUF_N];
        double[] Z6 = new double[BUF_N];
        double[] Z7 = new double[BUF_N];
        double[] Z8 = new double[BUF_N];
        double[] Z9 = new double[BUF_N];

        double[] Z_end = new double[BUF_N];

        void vid_filtr(double[] a)
        {
            int i = 0;

            for (i = 0; i < BUF_N; i++)
            {
                Z9[i] = Z8[i];
                Z8[i] = Z7[i];
                Z7[i] = Z6[i];
                Z6[i] = Z5[i];
                Z5[i] = Z4[i];
                Z4[i] = Z3[i];
                Z3[i] = Z2[i];
                Z2[i] = Z1[i];
                Z1[i] = Z0[i];
                Z0[i] = a[i];

                a[i] = (a[i] + Z0[i] + Z1[i] + Z2[i] + Z3[i] + Z4[i] + Z5[i] + Z6[i] + Z7[i] + Z8[i] + Z9[i]) / 11;

            }
        }
        //---------------------
        double[] x0 = new double[BUF_N];
        double[] x1 = new double[BUF_N];
        double[] x2 = new double[BUF_N];
        double[] x3 = new double[BUF_N];
        double[] x4 = new double[BUF_N];
        double[] x5 = new double[BUF_N];
        double[] x6 = new double[BUF_N];
        double[] x7 = new double[BUF_N];
        double[] x8 = new double[BUF_N];
        double[] x9 = new double[BUF_N];

        double[] x10 = new double[BUF_N];
        double[] x11 = new double[BUF_N];
        double[] x12 = new double[BUF_N];
        double[] x13 = new double[BUF_N];
        double[] x14 = new double[BUF_N];
        double[] x15 = new double[BUF_N];
        double[] x16 = new double[BUF_N];
        double[] x17 = new double[BUF_N];
        double[] x18 = new double[BUF_N];
        double[] x19 = new double[BUF_N];

        double[] x_end = new double[BUF_N];

        void vid2_filtr(double[] a)
        {
            int i = 0;

            for (i = 0; i < BUF_N; i++)
            {
                x19[i] = x18[i];
                x18[i] = x17[i];
                x17[i] = x16[i];
                x16[i] = x15[i];
                x15[i] = x14[i];
                x14[i] = x13[i];
                x13[i] = x12[i];
                x12[i] = x11[i];
                x11[i] = x10[i];
                x10[i] = x9[i];

                x9[i] = x8[i];
                x8[i] = x7[i];
                x7[i] = x6[i];
                x6[i] = x5[i];
                x5[i] = x4[i];
                x4[i] = x3[i];
                x3[i] = x2[i];
                x2[i] = x1[i];
                x1[i] = x0[i];
                x0[i] = a[i];

                a[i] = (a[i] + x0[i] + x1[i] + x2[i] + x3[i] + x4[i] + x5[i] + x6[i] + x7[i] + x8[i] + x9[i] + x10[i] +x11[i] + x12[i] +x13[i]+x14[i]+x15[i]+x16[i]+x17[i]+x18[i]+x19[i]) / 21;

            }
        }

        double[] c0 = new double[BUF_N];
        double[] c1 = new double[BUF_N];
        double[] c2 = new double[BUF_N];
        double[] c3 = new double[BUF_N];
        double[] c4 = new double[BUF_N];
        double[] c5 = new double[BUF_N];
        double[] c6 = new double[BUF_N];
        double[] c7 = new double[BUF_N];
        double[] c8 = new double[BUF_N];
        double[] c9 = new double[BUF_N];

        double[] c10 = new double[BUF_N];
        double[] c11 = new double[BUF_N];
        double[] c12 = new double[BUF_N];
        double[] c13 = new double[BUF_N];
        double[] c14 = new double[BUF_N];
        double[] c15 = new double[BUF_N];
        double[] c16 = new double[BUF_N];
        double[] c17 = new double[BUF_N];
        double[] c18 = new double[BUF_N];
        double[] c19 = new double[BUF_N];

        double[] c_end = new double[BUF_N];

        void vid3_filtr(double[] a)
        {
            int i = 0;

            //if (sch_filtr!=10) sch_filtr++; else

            for (i = 0; i < BUF_N; i++)
            {
                c19[i] = c18[i];
                c18[i] = c17[i];
                c17[i] = c16[i];
                c16[i] = c15[i];
                c15[i] = c14[i];
                c14[i] = c13[i];
                c13[i] = c12[i];
                c12[i] = c11[i];
                c11[i] = c10[i];
                c10[i] = c9[i];

                c9[i] = c8[i];
                c8[i] = c7[i];
                c7[i] = c6[i];
                c6[i] = c5[i];
                c5[i] = c4[i];
                c4[i] = c3[i];
                c3[i] = c2[i];
                c2[i] = c1[i];
                c1[i] = c0[i];
                c0[i] = a[i];

                a[i] = (a[i] + c0[i] + c1[i] + c2[i] + c3[i] + c4[i] + c5[i] + c6[i] + c7[i] + c8[i] + c9[i] + c10[i] + c11[i] + c12[i] + c13[i] + c14[i] + c15[i] + c16[i] + c17[i] + c18[i] + c19[i]) / 21;

            }
        }
        //---------------------
        double[] v0 = new double[BUF_N];
        double[] v1 = new double[BUF_N];
        double[] v2 = new double[BUF_N];
        double[] v3 = new double[BUF_N];
        double[] v4 = new double[BUF_N];
        double[] v5 = new double[BUF_N];
        double[] v6 = new double[BUF_N];
        double[] v7 = new double[BUF_N];
        double[] v8 = new double[BUF_N];
        double[] v9 = new double[BUF_N];

        double[] v10 = new double[BUF_N];
        double[] v11 = new double[BUF_N];
        double[] v12 = new double[BUF_N];
        double[] v13 = new double[BUF_N];
        double[] v14 = new double[BUF_N];
        double[] v15 = new double[BUF_N];
        double[] v16 = new double[BUF_N];
        double[] v17 = new double[BUF_N];
        double[] v18 = new double[BUF_N];
        double[] v19 = new double[BUF_N];

        double[] v_end = new double[BUF_N];

        void vid4_filtr(double[] a)
        {
            int i = 0;

            //if (sch_filtr!=10) sch_filtr++; else

            for (i = 0; i < BUF_N; i++)
            {
                v19[i] = v18[i];
                v18[i] = v17[i];
                v17[i] = v16[i];
                v16[i] = v15[i];
                v15[i] = v14[i];
                v14[i] = v13[i];
                v13[i] = v12[i];
                v12[i] = v11[i];
                v11[i] = v10[i];
                v10[i] = v9[i];

                v9[i] = v8[i];
                v8[i] = v7[i];
                v7[i] = v6[i];
                v6[i] = v5[i];
                v5[i] = v4[i];
                v4[i] = v3[i];
                v3[i] = v2[i];
                v2[i] = v1[i];
                v1[i] = v0[i];
                v0[i] = a[i];

                a[i] = (a[i] + v0[i] + v1[i] + v2[i] + v3[i] + v4[i] + v5[i] + v6[i] + v7[i] + v8[i] + v9[i] + v10[i] + v11[i] + v12[i] + v13[i] + v14[i] + v15[i] + v16[i] + v17[i] + v18[i] + v19[i]) / 21;

            }
        }
//-------------------------------------
        void SerialPort1DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
		{
		
		}

        (int n ,double Amax ) MAX_f (double [] m,int N)
        {
            int i = 0;
            double max = 0;
            int k = 0;

            for (i=0;i<N;i++)
            {
                if (max<m[i])
                {
                    max = m[i];
                    k = i;
                }
            }
            return (k,max);
        }

		void Button1Click(object sender, EventArgs e)
		{

            if (_isServerStarted)
            {
                Stop();
                Btn_start.Text = "StartServer";
            }
            else
            {
                Start();
                Btn_start.Text = "StopServer";
            }

        }
		void Port_enClick(object sender, EventArgs e)
		{
           
			
		}
		void Save_bottonClick(object sender, EventArgs e)
		{ 
   			saveFileDialog1.Filter = "text|*.txt|data|*.dat|fir coef|*.coff";  
   			saveFileDialog1.Title = "Save an File";  
   			
		 if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
            return;
        	// получаем выбранный файл
        	string filename = saveFileDialog1.FileName;
        	// сохраняем текст в файл
        	System.IO.File.WriteAllText(filename, Console1.Text);
        	//MessageBox.Show("Файл сохранен");
		    
		}


		void array_save (int [] a,int N)
		{
			string text="";
		
			System.IO.StreamWriter textFile = new System.IO.StreamWriter(@"c:\temp\c_sharp_test.txt");
			Debug.WriteLine("сохраняем сформированый массив в файл");
			
			for (int i = 0; i < N; i++)
		            {
						text=text+Convert.ToString(a[i])+"\r\n";
		            }
			textFile.WriteLine(text);
	          
			textFile.Close();
		}
	
		void N_fftTextChanged(object sender, EventArgs e)
		{
            int n = 0;
            
            n= Convert.ToInt16(text_N_fft.Text);

            if ((n==64)||(n==128)||(n==256)||(n==512)||(n==1024)||(n==2048)||(n==4096) || (n == 8192))   BUF_N =Convert.ToInt16(text_N_fft.Text);
            //Debug.WriteLine("изменили BUF_N:"+BUF_N);

		}
		void TextBox1TextChanged(object sender, EventArgs e)
		{
			Fsample=Convert.ToInt16(text_fsemple);
			//Debug.WriteLine("изменили BUF_N:"+BUF_N);
		}

        private void cmbWindow_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedWindowName = cmbWindow.SelectedValue.ToString();

            if (selectedWindowName == "Nutall3")    B_win = 2.02;
            if (selectedWindowName == "Hann")       B_win = 1.5;
            if (selectedWindowName == "None")       B_win = 1.0;
            if (selectedWindowName == "Hamming")    B_win = 1.37;
            if (selectedWindowName == "BH92")       B_win = 1.46;
            if (selectedWindowName == "Nutall4")    B_win = 2.02;
            if (selectedWindowName == "Nutall3A")   B_win = 2.02;
            if (selectedWindowName == "Nutall3B")   B_win = 2.02;
            if (selectedWindowName == "Nutall4A")   B_win = 2.02;

        }

        private void Open_file_BTN_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                fileName = openFileDialog1.FileName;
                text_from_file = File.ReadAllText(fileName);
   
            }
        }

        int[] data_0_i = new int[BUF_N];
        int[] data_0_q = new int[BUF_N];

        int BUF_convert(byte [] m, int col)
        {
            int i = 0;
            int k = 0;
            int l = 0;

            for (i = 4; i < col; i++)//
            {             
                    if (k == 0) data_0_q[l] = Convert.ToInt32(m[i])<<8;
                    if (k == 1) data_0_q[l] = data_0_q[l] + Convert.ToInt32(m[i]);
         
                    if (k == 2) data_0_i[l] = Convert.ToInt32(m[i]) << 8;
                    if (k == 3) data_0_i[l] = data_0_i[l] + Convert.ToInt32(m[i]);

                if (k != 3) k = k + 1;
                else
                {
                  k = 0;
                  l = l + 1;
                }
            }
            return 1;
        }

        void work1()
        {
            Array.Copy(data_0_i, packet_data_i, BUF_N);//копируем массив отсчётов в форму обработки	
            Array.Copy(data_0_q, packet_data_q, BUF_N);//копируем массив отсчётов в форму обработки	

            flag_NEW_FFT = 1;//сообщаем форме что пришёл новый массив fft
        }


        //-----------------------------------
        private void Timer2_Tick(object sender, EventArgs e)
        {
            int size_rcv;
            String buf_strng = "";

            Encoding utf8 = Encoding.GetEncoding("UTF-8");
            Encoding win1251 = Encoding.GetEncoding("Windows-1251");

            byte[] utf8Bytes;
            byte[] win1251Bytes;

            if ((Flag_comport_rcv == 1) && (serialPort1.IsOpen))
            {
                Flag_comport_rcv = 0;
                size_rcv = serialPort1.BytesToRead;
                serialPort1.Read(RCV, 0, size_rcv);
                // buf_strng = serialPort1.ReadExisting();

                buf_strng = Encoding.UTF8.GetString(RCV, 0, size_rcv);
                richTextBox1.Text = buf_strng;

                btn_com_open.Text = "send";
                btn_com_open.ForeColor = Color.Black;
                serialPort1.Close();
            }
        }
            private void Button1_Click(object sender, EventArgs e)
        {
            if (FLAG_filtr == 1) FLAG_filtr = 0; else FLAG_filtr = 1;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (FLAG_filtr == 2) FLAG_filtr = 0; else FLAG_filtr = 2;
        }

        private void btn_telnet_gen_Click(object sender, EventArgs e)
        {
            //create a new telnet connection to hostname "x.x.x.x" on port "5025"
            string host = textBox_ip_generator.Text;
            int    port = Convert.ToInt32(textBox_port_generator.Text);
            TelnetConnection tc = new TelnetConnection(host, port);
            string prompt = "";
            // while connected
            while (tc.IsConnected && prompt.Trim() != "exit")
            {
                prompt = "freq " + textBox_freq_gen.Text + " KHz";
                tc.WriteLine(prompt);
                prompt = "pow " + textBox_level_gen.Text + " DBm";
                tc.WriteLine(prompt);
                prompt = "outp " + " 1";
                tc.WriteLine(prompt);
                //    Console.Write(tc.Read());
                prompt = "exit";
            }
            Console.WriteLine("***DISCONNECTED");
            Console.ReadLine();
        }

        private void freq_send(int freq)
        {
            string command1 = "~0 freq:";

            if (serialPort1.IsOpen == false) serialPort1.PortName = textBox_com_port.Text;
                try
                {
                    command1 = command1 + Convert.ToString(freq) + ";";
                    serialPort1.Open();
                    serialPort1.Write(command1);
                     // здесь может быть код еще...
                }
                catch (Exception ex)
                {
                    btn_com_open.Text = "send";
                    btn_com_open.ForeColor = Color.Black;
                    // что-то пошло не так и упало исключение... Выведем сообщение исключения
                    Console.WriteLine(string.Format("Port:'{0}' Error:'{1}'", serialPort1.PortName, ex.Message));
                }
        }

        private void btn_com_open_Click(object sender, EventArgs e)
        {
            string command1 = "~0 freq:";
            string command2 = "~0 upr_at";

            if (serialPort1.IsOpen == false) serialPort1.PortName = textBox_com_port.Text;
            if (btn_com_open.Text == "send")
            {               
                try
                {
                    command1 = command1 + textBox_freq_m54.Text +"000"+ ";";
               //     command2 = command2 + channal_box.Text + ":" + textBox_att_m54.Text + ";";
 
                    serialPort1.Open();
           //       btn_com_open.Text = "trnsf";
                    btn_com_open.ForeColor = Color.Green;
                    serialPort1.Write(command1);
                //    serialPort1.Write(command2);
                    // здесь может быть код еще...
                }
                catch (Exception ex)
                {
                    btn_com_open.Text = "send";
                    btn_com_open.ForeColor = Color.Black;
                    // что-то пошло не так и упало исключение... Выведем сообщение исключения
                    Console.WriteLine(string.Format("Port:'{0}' Error:'{1}'", serialPort1.PortName, ex.Message));
                }
            }

            
            /*
            else if (serialPort1.IsOpen == true)
            {
                btn_com_open.Text = "open";
                btn_com_open.ForeColor = Color.Black;
                serialPort1.Close();
            }
            */
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            Flag_comport_rcv = 1;
        }


        int freq_start = 0;
        int freq_stop  = 0;
        int freq_step  = 0;
        int freq_current = 0;
        int freq_setup = 0;//переменна типа перебора - калибровка или просто просмотр частот
        int freq_last = 0;
        double progress_freq = 0;
        double progress_sum = 0;
        int freq_delta = 0;
        int flag_progress = 0;

        private void button3_Click(object sender, EventArgs e)
        {
            if (_isServerStarted==true)  timer3.Enabled = true;
            timer3.Interval = Convert.ToInt32(textBox_freq_delay.Text);
            freq_start = Convert.ToInt32(textBox_freq_start.Text);
            freq_stop  = Convert.ToInt32(textBox_freq_stop.Text);
            freq_step  = Convert.ToInt32(textBox_freq_step.Text);
            freq_last = 0;
            freq_current = freq_start;
            freq_delta = freq_stop - freq_start;
                                    progress_freq = freq_step;
            if (freq_delta>0)       progress_freq = progress_freq * 100 / freq_delta;
    //      Debug.WriteLine("progress_freq: " + progress_freq);
            progressBar1.Value = 0;
            flag_progress = 1;
            Console1.Text = "";
            freq_setup = 0;
        }

        

        private void timer3_Tick(object sender, EventArgs e)
        {
            string text = "";
            //create a new telnet connection to hostname "x.x.x.x" on port "5025"
            string host = textBox_ip_generator.Text;
            int port = Convert.ToInt32(textBox_port_generator.Text);
         // TelnetConnection tc = new TelnetConnection(host, port);
            string prompt = "";
            int freq_temp = 0;

            //Debug.WriteLine("freq_setup   : " + freq_setup);
            //Debug.WriteLine("freq_last    : " + freq_last);
            //Debug.WriteLine("freq_current : " + freq_current);
            //Debug.WriteLine("flag_progress: " + flag_progress);

            if (freq_last>0)
            {
            text = Convert.ToString(freq_last) + ";" + Convert.ToString(Math.Round(H_a, 2)) + ";" + Convert.ToString(Math.Round(H_b, 2)) + ";" + Convert.ToString(Math.Round(H_delta, 2));
            Console1.Text = Console1.Text + "\r\n" + text;
            }
            

            freq_temp = freq_current * 1000;
            if (freq_setup == 1) freq_send(freq_temp);//отсылаем текущую частоту в поделку для перестройки поделки её в центр диапазона

            prompt = "freq " + Convert.ToString(freq_current) + " KHz";
        //  tc.WriteLine(prompt);//отсылаем частоту в генератор SMA 100A
            freq_last = freq_current;
            freq_current = freq_current + freq_step;

            if (freq_current > freq_stop)
            {
                freq_current = freq_stop;
                progressBar1.Value = 100;
                timer3.Enabled = false;
                flag_progress = 0;
            } else
            {
              if (progressBar1.Value<99)  progressBar1.Value = progressBar1.Value + 1;
    //            progress_sum = progress_sum + progress_freq;
    //             if (progress_sum < 100) progressBar1.Value = Convert.ToInt32(progress_sum); 
    //            Debug.WriteLine("progress_sum: " + progress_sum);
            }

        }

        private void btn_corr_spectr_Click(object sender, EventArgs e)
        {
            if (btn_corr_spectr.Text=="OFF")
            {
                btn_corr_spectr.Text = "ON";
            } else
            {
                btn_corr_spectr.Text = "OFF";
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_com_open_2_Click(object sender, EventArgs e)
        {
            string command1 = "~0 freq:";
            string command2 = "~0 upr_at";
            string chanal = "";

            if (serialPort1.IsOpen == false) serialPort1.PortName = textBox_com_port.Text;
            if (btn_com_open.Text == "send")
            {
                try
                {
                    if (channal_box.Text == "1") chanal = "0"; else chanal = "1";
                    command2 = command2 + chanal + ":" + textBox_att_m54.Text + ";";

                    serialPort1.Open();
                    //       btn_com_open.Text = "trnsf";
                    btn_com_open.ForeColor = Color.Green;
                //    serialPort1.Write(command1);
                    serialPort1.Write(command2);
                    // здесь может быть код еще...
                }
                catch (Exception ex)
                {
                    btn_com_open.Text = "send";
                    btn_com_open.ForeColor = Color.Black;
                    // что-то пошло не так и упало исключение... Выведем сообщение исключения
                    Console.WriteLine(string.Format("Port:'{0}' Error:'{1}'", serialPort1.PortName, ex.Message));
                }
            }


            /*
            else if (serialPort1.IsOpen == true)
            {
                btn_com_open.Text = "open";
                btn_com_open.ForeColor = Color.Black;
                serialPort1.Close();
            }
            */
        }

        private void btn_calibrovka_Click(object sender, EventArgs e)
        {
            if (_isServerStarted == true) timer3.Enabled = true;
            timer3.Interval = Convert.ToInt32(textBox_freq_delay.Text);
            freq_start = 428856;//kHz
            freq_stop  = 441144;
            freq_step  = 48;//kHz
            freq_last  = 0;
            freq_current = freq_start;
            freq_delta = freq_stop - freq_start;
            progress_freq = freq_step;
            if (freq_delta > 0) progress_freq = progress_freq * 100 / freq_delta;
            //      Debug.WriteLine("progress_freq: " + progress_freq);
            progressBar1.Value = 0;
            flag_progress = 1;
            Console1.Text = "Режим калибровки:\r\n";
            freq_setup = 1;
            btn_corr_spectr.Text = "OFF";
        }

        double[] M_ach = new double[256];
        double[] F_ach = new double[256];
        double[] temp_Ach = new double[128];

        private void btn_load_ach_Click(object sender, EventArgs e)
        {
            int i = 0;
            int j = 0;
            int N_freq = 0;
            int freq_centr = 0;
            openFileDialog1.Filter = "text|*.txt|data|*.dat|fir coef|*.coff";
            openFileDialog1.Title = "Load an File";

            openFileDialog1.ShowDialog();
            // получаем выбранный файл
            string filename = openFileDialog1.FileName;
            // сохраняем текст в файл
            Console1.Text=System.IO.File.ReadAllText(filename);
            M_ach = BUF_getter(2, Console1.Text, 0, 145);//загружаем коэффициенты истиной АЧХ в массив
            F_ach = BUF_getter(1, Console1.Text, 0, 145);//загружаем частоты истиной АЧХ в массив

            //определяем центральную частоту в номере отсчёта массива
            freq_centr = Convert.ToInt32(textBox_freq_m54.Text);
            N_freq=find_number(freq_centr);
            for (i= (N_freq-64);i<(N_freq + 64);i++)
            {
                if ((i > 0) && (i < 256)) temp_Ach[j] = M_ach[i];//переписываем часть массива во временный массив
                        j++;
            }

            fig4.PlotData(M_ach, F_ach, 0, 0, 0, 0, 0, 0, 0, 0, 0); ;
            fig4.Show();
            //MessageBox.Show("Файл сохранен");
        }

        int find_number (int freq)
        {
            int i = 0;
            while (freq<Convert.ToInt32(F_ach[i]))
            {
                i = i + 1;
            }
            return (i);
        }

        double [] BUF_getter(int var,string text_from_file, int pos,int buf_n)
        {
            int i = 0;
            double[] m = new double[buf_n];

            for (i = 0; i < buf_n; i++)//размер буфера
            {
                var value = data_finder(text_from_file, pos);
              if (var==1)  m[i] = value.Item1;//получаем значение
              if (var==2)  m[i] = value.Item2;
                            pos = value.Item3;//получаем порядковый номер
            }
            return m;
        }

        public Tuple<double,double, int> data_finder(string text_from_file, int pos)
        {
            int i = 0;
            int a1, a2,a3,a4,a5;
            double data  = 0;
            double data2 = 0;
            int index;
            a1 = pos;
            i = a1;

            while ((text_from_file.Substring(i, 1) != "\r") && (i<(text_from_file.Length-1)))   //ищем новую строку
            {
                i = i + 1;
            }

            a3 = i+1;

            while ((text_from_file.Substring(i, 1) != ";")&&(i < (text_from_file.Length - 1)))  //ищем первый разделиетель
            {
                 i = i + 1;
            }
             i = i + 1;
            a1 = i;
            a4 = i - 1;

            if (i < (text_from_file.Length - 1))
            {
                while ((text_from_file.Substring(i, 1) != "\r") && (text_from_file.Substring(i, 1) != ";") && (i < (text_from_file.Length - 1))) //ищем второй разделитель
                {
                    i = i + 1;
                }
            }
            else
            {
                MessageBox.Show("не хватает данных!");
                return Tuple.Create(0.0,0.0,0);
            }
            
            a2 = i  - a1;
            a5 = a4 - a3;

       //     Debug.WriteLine("a1:" + a1);
       //     Debug.WriteLine("a2:" + a2);

            index = i;

          //       Debug.WriteLine(">" + text_from_file.Substring(a3, a5));

            try
            {
                data2 = Convert.ToDouble(text_from_file.Substring(a3, a5));
            }
            catch
            {
                MessageBox.Show("Введите правильные данные");
            }
            try
            {
                data = Convert.ToDouble(text_from_file.Substring(a1, a2));
            }
            catch
            {
                MessageBox.Show("Введите правильные данные");
            }            

            return Tuple.Create(data2,data, index);
        }

    }
}
